var app = require('express')();
var express = require('express');
var http = require('http').Server(app);
var bodyParser = require("body-parser");
var fs = require('fs');


app.use(bodyParser.urlencoded({ extended: false }));
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Credentials", "true");
  res.header("Access-Control-Allow-Headers", "Accept, X-Access-Token, X-Application-Name, X-Request-Sent-Time");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Origin", "*");
  //res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.get('/', function(req, res){
  app.use('/game', express.static(__dirname + '/game'));
  res.redirect('/game/');
  //res.sendFile(__dirname + '/game/index.html');
  console.log('get made');
});

app.get('/bar', function(req, res){
  //res.sendFile(__dirname + '/index.html');
  res.sendFile(__dirname + "/test.bin");
  console.log('get made');
});

app.post('/foo', function(req, res){
  console.log('post made');
  console.log(req.body.foo);
  fs.writeFile('test.bin', req.body.foo);
  console.log('post completed ');
});

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});


http.listen(8082, function(){
  console.log('listening on *:8082');
});
